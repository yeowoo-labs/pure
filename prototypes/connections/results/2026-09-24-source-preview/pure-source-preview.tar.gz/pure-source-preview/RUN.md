# Pure native source preview

This bundle contains the C17 execution core, the authored document app, its
CLI and optional terminal/HTTP/TLS hosts, plus the Workbench sources used by
the integration checks. It excludes prior benchmark results and build outputs.
`manifest.json` records the exact files and their SHA-256 hashes.

Build and run the small default path from the extracted directory:

```sh
make -C prototypes/connections check-portable
make -C prototypes/connections fixed-editor fixed-tui
mkdir -p /tmp/pure-source-store
printf 'hello Pure\n' > /tmp/pure-source-insert.txt
prototypes/connections/build/pure-edit-fixed --store /tmp/pure-source-store \
  edit note 0 0 0 /tmp/pure-source-insert.txt
prototypes/connections/build/pure-edit-fixed --store /tmp/pure-source-store show note
```

`check-portable` builds the C hosts and runs the host-neutral C behavior tests.
On Linux AArch64, `make -C prototypes/connections check-release` additionally
checks the measured code, dependency and process-memory ceilings and the actual
document/HTTP paths; it needs Python 3, Node.js, and GNU `size`/`readelf`.
The source-loading CLI can run a changed `.pure` definition with
`make -C prototypes/connections editor` and `--program PATH`.

The fixed CLI and TUI contain one build-time prepared `editor.pure` and do not
reload a changed definition. The Workbench scalar-native build additionally
requires Zig 0.15.2; the GTK and TLS hosts need their platform libraries.
macOS source compilation and execution are not yet verified. This preview is
not a signed release, does not bundle system libraries, and does not establish
a redistribution license.
