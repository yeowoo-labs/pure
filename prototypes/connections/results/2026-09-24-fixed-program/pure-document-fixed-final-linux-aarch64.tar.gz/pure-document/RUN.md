# Pure fixed document runner — Linux AArch64

This artifact runs one build-time prepared editor.pure definition. It has no
source parser, compiler, GTK, HTTP or TLS host. Editing a .pure file does not
change this binary; rebuild it with `make fixed-editor` in the source tree.

    bin/pure-edit-fixed --store STORE edit KEY 0 0 0 INSERT_FILE
    bin/pure-edit-fixed --store STORE show KEY

The external storage files use the default PUREB001 format. The ELF binary
needs the host's libc and is not a static or macOS package.
