# Pure document preview — Linux native build

This archive includes the CLI and editable editor.pure program. HTTP, TLS peer,
and GTK hosts are included only when listed in manifest.json. Shared system libraries are not bundled;
manifest.json records every binary's direct dependencies.

From this directory, try a local edit:

    printf 'hello Pure\n' > /tmp/pure-insert.txt
    bin/pure-edit --program share/editor.pure --store /tmp/pure-preview-store \
      edit note 0 0 0 /tmp/pure-insert.txt
    bin/pure-edit --program share/editor.pure --store /tmp/pure-preview-store show note

When selected, the same program and store can be opened with the GTK window:

    bin/pure-edit-window --program share/editor.pure \
      --store /tmp/pure-preview-store note

When selected, the TLS peer needs your own CA and server/client certificates. The server
certificate needs a DNS SAN matching SERVER_DNS; the client certificate needs
a DNS SAN matching CLIENT_DNS. This example binds only to loopback:

    bin/pure-document-peer serve 127.0.0.1 9443 share/editor.pure \
      /tmp/pure-preview-store CA.pem SERVER.pem SERVER.key CLIENT_DNS
    bin/pure-document-peer call 127.0.0.1 9443 SERVER_DNS share/editor.pure \
      CA.pem CLIENT.pem CLIENT.key show note

When selected, the HTTP host is a plaintext compatibility adapter; bind it only to loopback.
This preview was checked on Linux AArch64. It is not a static or macOS package.
