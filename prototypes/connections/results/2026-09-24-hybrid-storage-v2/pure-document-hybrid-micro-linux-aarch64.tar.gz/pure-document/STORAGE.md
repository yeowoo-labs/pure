# Selected inline/page storage experiment

Objects up to 16 KiB use the existing PUREB001 file format. Larger objects
use PUREP001 page roots and append-only data generations. The current flat
binary cannot read PUREP001 objects, so use a new --store directory for this
preview. This is a selected research build, not the default backend or a
bidirectional migration path. It requires a Linux host with 16 KiB OS pages.
See docs/research/034-hybrid-document-storage.md in the source repository.
