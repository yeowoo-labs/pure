#!/usr/bin/env python3
"""Check whole-process RSS for the selected CLI document workload."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent


def measure(helper, command):
    result = subprocess.run([helper, *command], capture_output=True, text=True,
                            check=True, timeout=15)
    sample = json.loads(result.stdout)
    if sample['exit_code']:
        raise AssertionError(f'workload failed: {command}: {sample}')
    return sample['max_rss_kib']


def check(build, fixed=False):
    budget_path = HERE / 'memory-budget.json'
    budget = json.loads(budget_path.read_text())
    if platform.system() != 'Linux' or platform.machine() != 'aarch64':
        raise RuntimeError('reviewed memory profile requires Linux AArch64')
    binary = (build / ('pure-edit-fixed' if fixed else 'pure-edit')).resolve()
    helper = (build / 'measure-peak-rss').resolve()
    program = HERE / 'examples/editor.pure'
    with tempfile.TemporaryDirectory(prefix='pure-micro-memory-') as name:
        root = Path(name)
        small, large = root / 'small', root / 'large'
        small.write_bytes(b'A')
        large.write_bytes(b'B' * 1_048_576)
        store = root / 'store'
        base = [binary]
        if not fixed:
            base += ['--program', program]
        base += ['--store', store]
        samples = {
            'small_edit_rss_kib': measure(helper, [*base, 'edit', 'small', '0', '0', '0', small]),
            'one_mib_edit_rss_kib': measure(helper, [*base, 'edit', 'large', '0', '0', '0', large]),
            'one_mib_show_rss_kib': measure(helper, [*base, 'show', 'large']),
        }
        shown = subprocess.run([*map(str, base), 'show', 'large'],
                               capture_output=True, check=True, timeout=15)
        if shown.stdout != large.read_bytes():
            raise AssertionError('measured document was not stored correctly')
    failures = [f'{name}: {value} > {budget["max_" + name]}'
                for name, value in samples.items() if value > budget['max_' + name]]
    scope = budget['scope']
    if fixed:
        scope = scope.replace('program parsing', 'the embedded prepared program')
    return {'passed': not failures, 'failures': failures, 'profile': budget['profile'],
            'variant': 'fixed-program' if fixed else 'source-program',
            'scope': scope, 'samples': samples,
            'budget_sha256': hashlib.sha256(budget_path.read_bytes()).hexdigest(),
            'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'platform': platform.platform()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--fixed', action='store_true',
                        help='measure the parser-free fixed-program editor')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.output and args.output.exists():
        parser.error('evidence file already exists')
    result = check(args.build, args.fixed)
    output = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end='')
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
