#define _DEFAULT_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

/* Linux test helper: fork from a small native process so the interpreter's
 * pre-exec RSS cannot become the measured child's peak. Not shipped. */
int main(int argc, char **argv) {
    if (argc < 2) return 2;
    pid_t child = fork();
    if (child < 0) return 2;
    if (!child) {
        int null = open("/dev/null", O_WRONLY);
        if (null < 0 || dup2(null, STDOUT_FILENO) < 0 ||
            dup2(null, STDERR_FILENO) < 0) _exit(127);
        close(null);
        execvp(argv[1], argv + 1);
        _exit(127);
    }
    struct rusage usage;
    int status;
    if (wait4(child, &status, 0, &usage) < 0) return 2;
    if (!WIFEXITED(status)) return 2;
    printf("{\"exit_code\":%d,\"max_rss_kib\":%ld}\n",
           WEXITSTATUS(status), usage.ru_maxrss);
    return 0;
}
