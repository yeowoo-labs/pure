# Pure fixed document runner — Linux AArch64

This artifact runs one build-time prepared editor.pure definition. It has no
source parser, compiler, GTK or TLS host. Editing a .pure file does not
change this binary; rebuild it with `make fixed-editor` in the source tree.

    bin/pure-edit-fixed --store STORE edit KEY 0 0 0 INSERT_FILE
    bin/pure-edit-fixed --store STORE show KEY

When manifest.json lists pure-connections-fixed, it serves the same definition
and store through a loopback HTTP compatibility boundary:

    bin/pure-connections-fixed --store STORE --port 8767

When manifest.json lists pure-edit-tui-fixed, it opens a native terminal
editor for the same stored document. Ctrl+S saves, Ctrl+O opens another key,
Ctrl+R reloads, and Ctrl+Q quits:

    bin/pure-edit-tui-fixed --store STORE note

The external storage files use the default PUREB001 format. The ELF binary
needs the host's libc and is not a static or macOS package.
