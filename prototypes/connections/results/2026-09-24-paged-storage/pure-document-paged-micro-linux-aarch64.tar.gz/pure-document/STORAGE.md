# Selected page storage format

This preview uses the PUREP001 16 KiB-page store. It cannot open PUREB001
flat-store objects. Use a new --store directory; this is a research format,
not a migration or a default storage backend. Small objects currently pay a
full-page write cost. See docs/research/033-paged-document-storage.md in the
source repository for measured boundaries and limitations.
